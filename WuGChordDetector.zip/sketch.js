// Listening Machines
// Week 5
// Essentia.js
// Example of a processing chain: Chord Detection
//
// This is a version of the Chord Detection example that does 
// not utilize any intermediary libraries. In the other examples
// of Essentia.js, we'll use the intermediary library: MLTK.js.
//
// This sketch is a reference for integrating Essentia.js wiithout
// using MLTK.js.
//
// MLTK.js wraps the libraries Meyda.js and Essentia.js to provide
// easy access to a comprehensive set of signal analysis,


// function to display the pitch on the html elements
function displayChordInfo(features) {
  try {
    if (features.chords.strength.toFixed(2) > chordThreshold) {
      strengthInfo.innerHTML = "Strength: " + features.chords.strength.toFixed(2);
      chordInfo.innerHTML = features.chords.chord;
    } else {
      chordInfo.innerHTML = " ∞ ";
      strengthInfo.innerHTML = "Strength: " + features.chords.strength.toFixed(2);
    }
  } catch (error) {}
}

// function to draw the pitch on the canvas
function drawChordInfo(features) {
  if (features.chords.strength.toFixed(2) > chordThreshold) {
    strengthInfo.innerHTML = "Strength: " + features.chords.strength.toFixed(2);
    chordInfo.innerHTML = features[chords].chord;
  } else {
    chordInfo.innerHTML = "---";
    strengthInfo.innerHTML = "Strength: " + features.chords.strength.toFixed(2);
  }
}


// function to draw the pitch on the canvas
function printChordInfo(features) {
  if (features.strength > chordThreshold) {
    console.log(
      "Strength: " + features[chords].strength.toFixed(2),
      features.chord
    );
  } else {
    console.log("Strength: " + features[chords].strength.toFixed(2), "---");
  }
}

function drawChromas(data, originX, originY, plotWidth, plotHeight, strength, chromaRectSize) {
  let pitchClasses = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
  
  for (let i = 0; i < data.length; i++) {
    let intensity = map(strength, 0.0, 1.0, 0, 100, true);
    let binWidth = width / data.length;
    let hue = map(i, 0, data.length, 0, 360);

    push();
    colorMode(HSB, 360, 100, 1.0, 100);
    // stroke(hue, 50, strength, intensity);
    noStroke();
    // print(strength);
    fill(hue, 50, strength, intensity);

    rectMode(CENTER);

    let offset = 10 / data.length + 50;
    let x = originX + i * offset;
    let y = originY + 70;
    let binHeight = binWidth * (intensity / 100);

    let rectSize = map(data[i], 0.0, 1.0, 0.0, strength * chromaRectSize);
    
    if(data[i] > chordThreshold){
      rect(x, y, rectSize, rectSize);
    }

    fill(255);
    text(pitchClasses[i], x - 5, originY + 30);

    pop();
    }
}

function setup() {
  createCanvas(windowWidth, 200);

  // create Web Audio API audio context. Throw an error if the browser has no support
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    audioCtx = new AudioContext();
  } catch (e) {
    throw "Could not instantiate AudioContext: " + e.message;
  }

  background(100);
}

function draw() {
  background(20, 50);
  try {
    displayChordInfo(audioFeatureData);
    // printChordInfo(audioFeatureData['chords']);
    //console.log(audioFeatureData['hpcp']);
    let chordStrength = audioFeatureData["chords"].strength;
    let x = windowWidth / 2 - 280;
    let y = height / 2;
    
    drawChromas(audioFeatureData["hpcp"], x, y, windowWidth, 800, chordStrength, 50);
  } catch (error) {}
}
