// declare some global variables
// global var to load essentia instance from wasm build
let essentia;
let isEssentiaInstance = false;

let startButton = document.getElementById("btn-start");
let stopButton = document.getElementById("btn-stop");

document.addEventListener("DOMContentLoaded", function() {
  // add event listeners to button objects
  startButton.addEventListener("click", function() {
    EssentiaWASM().then(function(essentiaModule) {
      if (!isEssentiaInstance) {
        essentia = new Essentia(essentiaModule);
        isEssentiaInstance = true;
      }

      startMicRecordStream(audioCtx,bufferSize,onRecordFeatureExtractor);
    });
  }); // end startButton onClick

  stopButton.addEventListener("click", function() {
    stopMicRecordStream();
  });
});

// HTML elements


let strengthInfo = document.getElementById("strength");
let chordInfo = document.getElementById("chord");

// global var for web audio api AudioContext
let audioCtx;

// buffer size microphone stream
let bufferSize = 4096;
// threshold for filtering the chord detection results
let chordThreshold = 0.75;
// global var getUserMedia mic stream
let gumStream;

let audioFeatureData = {};

// record native microphone input and do further audio processing on each audio buffer using the given callback functions
function startMicRecordStream(audioCtx,bufferSize,onProcessCallback,callback) {
  // cross-browser support for getUserMedia
  navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
  window.URL = window.URL || window.webkitURL || window.mozURL || window.msURL;

  if (audioCtx.state === "suspended") audioCtx.resume();
  if (navigator.getUserMedia) {
    console.log("Initializing audio...");
    navigator.getUserMedia(
      { audio: true, video: false },
      function (stream) {
        gumStream = stream;
        if (gumStream.active) {
          console.log("Audio context sample rate = " + audioCtx.sampleRate);
          var mic = audioCtx.createMediaStreamSource(stream);
          // We need the buffer size that is a power of two
          if (bufferSize % 2 != 0 || bufferSize < 256) {
            throw "Choose a buffer size that is a power of two and greater than 256";
          }
          const scriptNode = audioCtx.createScriptProcessor(bufferSize, 1, 1);
          // onprocess callback (here we can use essentia.js algos)
          scriptNode.onaudioprocess = onProcessCallback;
          // It seems necessary to connect the stream to a sink for the pipeline to work, contrary to documentataions.
          // As a workaround, here we create a gain node with zero gain, and connect temp to the system audio output.
          const gain = audioCtx.createGain();
          gain.gain.setValueAtTime(0, audioCtx.currentTime);
          mic.connect(scriptNode);
          scriptNode.connect(gain);
          gain.connect(audioCtx.destination);

          if (callback) {
            callback();
          }
        } else {
          throw "Mic stream not active";
        }
      },
      function (message) {
        throw "Could not access microphone - " + message;
      }
    );
  } else {
    throw "Could not access microphone - getUserMedia not available";
  }
}

// stop mic recording
function stopMicRecordStream() {
  console.log("Stopped recording ...");
  // stop mic stream
  gumStream.getAudioTracks().forEach(function (track) { track.stop(); });
  audioCtx.suspend();
}

// ScriptNodeProcessor callback function to extract pitchyin feature using essentia.js and plotting it on the front-end
function onRecordFeatureExtractor(event) {
  // convert the float32 audio data into std::vector<float> for using essentia algos
  let bufferSignal = essentia.arrayToVector(event.inputBuffer.getChannelData(0));

  if (!bufferSignal) {
    throw "onRecordingError: empty audio signal input found!";
  }

  audioFeatureData = extractFeaturesCallback(bufferSignal, bufferSize);
}

// This is where we can call the essentia.js functions. This function is the callback for used by Essentia's extractFeatures process.
// The `extractFeaturesCallback` callback is run on a seperate thread and is called every audio frame (much faster than the draw loop)
// It's important to not do anything other than audio processing inside this function. You never want to be calling any drawing functions from within here, this function should solely be used for computing the necessary data needed for the tasks at hand.
//
// In this example, the audio signal data is used compute chords from an audio buffer vector
// To do so, we need to compute the following signal process chain:
//   audio frame => windowing => spectrum => spectral peak => spectral whitening => HPCP => ChordDetection
//
// Similar diagrams to this, flow charts describing processing chain, can be found in white papers, text books, and within Essentia's  documentation.
// For example: https://essentia.upf.edu/howto_standard_extractor.html
//
// This chaining system allows you to use any of the algorithms available in Essentia.js

const extractFeaturesCallback = function (audioVectorBuffer, frameSize) {
  //
  let hpcpPool = new essentia.module.VectorVectorFloat();

  // Audio Frame -> Windowing
  let windowOut = essentia.Windowing(audioVectorBuffer,true,frameSize,"blackmanharris62");

  // Here we run the window into the spectrum
  // Windowing -> Spectrum
  let spectrumOut = essentia.Spectrum(windowOut.frame, frameSize);

  let peaksOut = essentia.SpectralPeaks(spectrumOut.spectrum,0,4000,100,60,"frequency",audioCtx.sampleRate);

  let whiteningOut = essentia.SpectralWhitening(spectrumOut.spectrum,peaksOut.frequencies,peaksOut.magnitudes,4000,audioCtx.sampleRate);

  let hpcpOut = essentia.HPCP(peaksOut.frequencies,whiteningOut.magnitudes,true,500,0,4000,false,60,true,"unitMax",440,audioCtx.sampleRate,12);

  hpcpPool.push_back(hpcpOut.hpcp);

  let chordDetect = essentia.ChordsDetection(hpcpPool,bufferSize,audioCtx.sampleRate);

  let detectedChord = chordDetect.chords.get(0);

  let chordsStrength = chordDetect.strength.get(0);

  return {
    buffer: audioVectorBuffer,
    window: windowOut,
    spectrum: spectrumOut,
    peaks: peaksOut,
    hpcp: essentia.vectorToArray(hpcpOut.hpcp),
    whitening: whiteningOut,
    chords: {
      chord: detectedChord,
      strength: chordsStrength,
    },
  };
};